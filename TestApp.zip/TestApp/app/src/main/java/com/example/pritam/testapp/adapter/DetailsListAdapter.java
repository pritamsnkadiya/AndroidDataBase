package com.example.pritam.testapp.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.pritam.testapp.R;
import com.example.pritam.testapp.database.DBHandler;
import com.example.pritam.testapp.database.modelClass.ClientDetailsModel;

import java.util.ArrayList;

public class DetailsListAdapter extends RecyclerView.Adapter<DetailsListAdapter.ViewHolder> {

    private Context context;
    private ArrayList<ClientDetailsModel> modelList;

    public DetailsListAdapter(Context context, ArrayList<ClientDetailsModel> modelList) {
        this.context = context;
        this.modelList = modelList;
    }

    public void filterList(ArrayList<ClientDetailsModel> filterdNames) {
        this.modelList = filterdNames;
        notifyDataSetChanged();
    }

    @Override
    public DetailsListAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_list, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(DetailsListAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.cName.setText(modelList.get(position).getC_name());
        viewHolder.metting.setText(modelList.get(position).getC_Mwith ());
        viewHolder.cEmail.setText(modelList.get(position).getC_email());
        viewHolder.purpose.setText(modelList.get(position).getC_purpose ());
        viewHolder.comments.setText(modelList.get(position).getC_comments ());
        viewHolder.date.setText(modelList.get(position).getDate());
        viewHolder.mobile.setText(modelList.get(position).getC_mobile ());

        viewHolder.mDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog alertDialog = new AlertDialog.Builder(context).create();
                alertDialog.setTitle("Delete");
                alertDialog.setMessage("Do you want to delete this item!!!");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                String id = modelList.get(position).getId();
                                modelList.remove(position);
                                notifyDataSetChanged();
                                DBHandler db = new DBHandler(context);
                                long result = db.deleteData(id);
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return modelList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView cName;
        TextView cEmail;
        TextView metting;
        TextView purpose;
        TextView comments;
        TextView date,mobile;
        LinearLayout mDelete;

        public ViewHolder(View itemView) {
            super(itemView);

            cName = itemView.findViewById(R.id.cName);
            metting = itemView.findViewById(R.id.cMobile);
            cEmail = itemView.findViewById(R.id.cEmail);
            purpose = itemView.findViewById(R.id.aName);
            comments = itemView.findViewById(R.id.aMobile);
            date = itemView.findViewById(R.id.date);
            mobile= itemView.findViewById(R.id.mobile);
            mDelete = itemView.findViewById(R.id.delete);
        }
    }
}