package com.example.pritam.testapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pritam.testapp.adapter.DetailsListAdapter;
import com.example.pritam.testapp.adapter.SearchDateDetailsListAdapter;
import com.example.pritam.testapp.database.DBHandler;
import com.example.pritam.testapp.database.modelClass.ClientDetailsModel;

import java.util.ArrayList;

public class DetailListActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager layoutManager;
    DetailsListAdapter mAdapter;
    SearchDateDetailsListAdapter mAdapterDate;
    public EditText Cname;
    ArrayList<ClientDetailsModel> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_detail_list);

        Cname = (EditText) findViewById (R.id.Cname);

        mRecyclerView = findViewById(R.id.recycler_view);
        setAdapter();


        Cname.addTextChangedListener (new TextWatcher () {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                //after the change calling the method and passing the search input
                filter (editable.toString ());

            }
        });
    }

    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<ClientDetailsModel> filterdNames = new ArrayList<> ();

        //looping through existing elements
        for (ClientDetailsModel s : list) {
            //if the existing elements contains the search input
            if (s.getDate ().toLowerCase ().contains (text.toLowerCase ())) {
                //adding the element to filtered list
                filterdNames.add (s);
            }
        }

        //calling a method of the adapter class and passing the filtered list
        try {
            mAdapter.filterList (filterdNames);
        }catch (Exception e){e.getStackTrace ();}
    }

    void setAdapter() {

        DBHandler db = new DBHandler(getApplicationContext());
        list = db.getAllDataList();
        if (list.size()>0){
            mRecyclerView.setHasFixedSize(true);
            layoutManager = new LinearLayoutManager (getApplicationContext());
            mRecyclerView.setLayoutManager(layoutManager);
            mAdapter = new DetailsListAdapter(DetailListActivity.this, list);
            mAdapterDate = new SearchDateDetailsListAdapter (DetailListActivity.this, list);
            mRecyclerView.setAdapter(mAdapter);
        }else {
            Toast.makeText(DetailListActivity.this, "Data list is empty!",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
