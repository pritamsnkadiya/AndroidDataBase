package com.example.pritam.testapp;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pritam.testapp.adapter.RecyclerTouchListener;
import com.example.pritam.testapp.adapter.SearchDetailsListAdapter;
import com.example.pritam.testapp.database.DBHandler;
import com.example.pritam.testapp.database.modelClass.ClientDetailsModel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.example.pritam.testapp.init.ApplicationAppContext.getAppContext;

public class MainActivity extends AppCompatActivity implements LocationListener {

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    public EditText Cname, Mwith, email, comments, mobile;
    public TextView date_time, location_;
    public Button submit;
    Boolean bool = false;
    LinearLayout mList;
    Spinner productSpinner;
    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager layoutManager;
    SearchDetailsListAdapter mAdapter;
    ArrayList<ClientDetailsModel> list = new ArrayList<> ();
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog DatePickerDialog1;
    protected LocationManager locationManager;
    protected Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);


        dateFormatter = new SimpleDateFormat ("dd-MMM-yyyy", Locale.US);

        Cname = (EditText) findViewById (R.id.Cname);
        Mwith = (EditText) findViewById (R.id.Mwith);
        email = (EditText) findViewById (R.id.email);
        mobile = (EditText) findViewById (R.id.phone);
        comments = (EditText) findViewById (R.id.comments);
        date_time = (TextView) findViewById (R.id.date_time);
        location_ = (TextView) findViewById (R.id.location);

        submit = (Button) findViewById (R.id.submit);
        mList = (LinearLayout) findViewById (R.id.list);
        productSpinner = (Spinner) findViewById (R.id.purpose);
        mRecyclerView = findViewById (R.id.recycler_view);

        //create a date string.
        String currentDateTimeString = DateFormat.getDateTimeInstance ().format (new Date ());
        date_time.setText (currentDateTimeString.toString ());
        checkLocationPermission ();
        try {
            locationManager = (android.location.LocationManager) getSystemService (android.content.Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates (android.location.LocationManager.GPS_PROVIDER, 5000, 5, this);
        } catch (SecurityException e) {
            e.printStackTrace ();
        }

        Calendar newDate = Calendar.getInstance ();
        String date1 = dateFormatter.format (newDate.getTime ());
        addView (date1);

        submit.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {

                if (Cname.getText ().toString ().equals ("")) {
                    Toast.makeText (MainActivity.this, "Please Enter Company Name ", Toast.LENGTH_SHORT).show ();
                    return;
                }
                if (email.getText ().toString ().equals ("")) {
                    Toast.makeText (MainActivity.this, "Please Enter Email ", Toast.LENGTH_SHORT).show ();
                    return;
                }
                if (Mwith.getText ().toString ().equals ("")) {
                    Toast.makeText (MainActivity.this, "Please Enter Meeting Name with ", Toast.LENGTH_SHORT).show ();
                    return;
                }
                if (mobile.getText ().toString ().equals ("")) {
                    Toast.makeText (MainActivity.this, "Please Enter Mobile No. ", Toast.LENGTH_SHORT).show ();
                    return;
                }
                if (comments.getText ().toString ().equals ("")) {
                    Toast.makeText (MainActivity.this, "Please Enter Comments ", Toast.LENGTH_SHORT).show ();
                    return;
                }
                callData ();
                Toast.makeText (MainActivity.this, "Inserted !", Toast.LENGTH_SHORT).show ();
                Intent intent = new Intent (MainActivity.this, MainActivity.class);
                startActivity (intent);

            }
        });

        mList.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                DBHandler db = new DBHandler (getApplicationContext ());
                ArrayList<ClientDetailsModel> list = new ArrayList<> ();
                list = db.getAllDataList ();
                if (list.size () > 0) {
                    Intent intent = new Intent (MainActivity.this, DetailListActivity.class);
                    startActivity (intent);
                } else {
                    Toast.makeText (MainActivity.this, "Data list is empty!",
                            Toast.LENGTH_SHORT).show ();
                }
            }
        });

        Cname.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                Cname.setText ("");
                Mwith.setText ("");
                email.setText ("");
                mobile.setText ("");
            }
        });

        Cname.addTextChangedListener (new TextWatcher () {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                //after the change calling the method and passing the search input
                mRecyclerView.setVisibility (View.VISIBLE);

                filter (editable.toString ());
            }
        });
        setAdapter ();

        // row click listener
        mRecyclerView.addOnItemTouchListener (new RecyclerTouchListener (getAppContext (),
                mRecyclerView, new RecyclerTouchListener.ClickListener () {
            @Override
            public void onClick(View view, int position) {
                Log.d ("i am Click on ", "Main " + position);
                Cname.setText (list.get (position).getC_name ());
                Mwith.setText (list.get (position).getC_Mwith ());
                email.setText (list.get (position).getC_email ());
                mobile.setText (list.get (position).getC_mobile ());
                mRecyclerView.setVisibility (View.GONE);
            }

            @Override
            public void onLongClick(View view, int position) {
                Toast.makeText (getAppContext (), position + " is selected!", Toast.LENGTH_SHORT).show ();
            }
        }));

       /* Location location = appLocationService
                .getLocation(LocationManager.GPS_PROVIDER);*/
    }


    public void showSettingsAlert() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder (
                MainActivity.this);
        alertDialog.setTitle ("SETTINGS");
        alertDialog.setMessage ("Enable Location Provider! Go to settings menu?");
        alertDialog.setPositiveButton ("Settings",
                new DialogInterface.OnClickListener () {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent (
                                Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        MainActivity.this.startActivity (intent);
                    }
                });
        alertDialog.setNegativeButton ("Cancel",
                new DialogInterface.OnClickListener () {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel ();
                    }
                });
        alertDialog.show ();
    }

    private class GeocoderHandler extends Handler {
        @Override
        public void handleMessage(Message message) {
            String locationAddress;
            switch (message.what) {
                case 1:
                    Bundle bundle = message.getData ();
                    locationAddress = bundle.getString ("address");
                    break;
                default:
                    locationAddress = null;
            }
            location_.setText (locationAddress);
        }
    }


    private void addView(String date1) {

        date_time.setText (date1);
        date_time.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                setDateField (date_time);
            }
        });
    }

    private void setDateField(final TextView textView) {

        final Calendar newCalendar = Calendar.getInstance ();

        DatePickerDialog1 = new DatePickerDialog (this, new android.app.DatePickerDialog.OnDateSetListener () {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                Calendar newDate = Calendar.getInstance ();
                newDate.set (year, monthOfYear, dayOfMonth);
                String date1 = dateFormatter.format (newDate.getTime ());
                textView.setText (date1);
            }

        }, newCalendar.get (Calendar.YEAR), newCalendar.get (Calendar.MONTH), newCalendar.get (Calendar.DAY_OF_MONTH));
        DatePickerDialog1.show ();
    }


    void setAdapter() {
        DBHandler db = new DBHandler (getApplicationContext ());
        list = db.getAllDataList ();
        if (list.size () > 0) {
            mRecyclerView.setHasFixedSize (true);
            layoutManager = new LinearLayoutManager (getApplicationContext ());
            mRecyclerView.setLayoutManager (layoutManager);
            mAdapter = new SearchDetailsListAdapter (MainActivity.this, list);
            mRecyclerView.setAdapter (mAdapter);
        } else {
            Toast.makeText (MainActivity.this, "Data list is empty!",
                    Toast.LENGTH_SHORT).show ();
        }
    }

    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<ClientDetailsModel> filterdNames = new ArrayList<> ();

        //looping through existing elements
        for (ClientDetailsModel s : list) {
            //if the existing elements contains the search input
            if (s.getC_name ().toLowerCase ().contains (text.toLowerCase ())) {
                //adding the element to filtered list
                filterdNames.add (s);
            }
        }

        //calling a method of the adapter class and passing the filtered list
        try {
            mAdapter.filterList (filterdNames);
        } catch (Exception e) {
            e.getStackTrace ();
        }
    }

    private void callData() {

        ClientDetailsModel data = new ClientDetailsModel ();
        data.setC_name (Cname.getText ().toString ());
        data.setC_Mwith (Mwith.getText ().toString ());
        data.setC_email (email.getText ().toString ());
        data.setC_mobile (mobile.getText ().toString ());
        data.setC_purpose (productSpinner.getSelectedItem ().toString ());
        data.setC_comments (comments.getText ().toString ());
        data.setDate (date_time.getText ().toString ());
        data.setC_location (location_.getText ().toString ());

        DBHandler db = new DBHandler (getApplicationContext ());
        long result = db.insertData (data);
        if (result != -1) {
            bool = true;
        } else {
            bool = false;
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d ("Location", "status" + location.toString ());

        if (location != null) {
            double latitude = location.getLatitude ();
            double longitude = location.getLongitude ();
            LocationAddress locationAddress = new LocationAddress ();
            locationAddress.getAddressFromLocation (latitude, longitude,
                    getApplicationContext (), new MainActivity.GeocoderHandler ());
        } else {
            showSettingsAlert ();
        }
        location_.setText ("Current Location: " + location.getLatitude () + ", " + location.getLongitude ());
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {
        Log.d ("Latitude", "status");
    }

    @Override
    public void onProviderEnabled(String s) {
        Toast.makeText (MainActivity.this, "Please Enable GPS and Internet", Toast.LENGTH_LONG).show ();
    }

    @Override
    public void onProviderDisabled(String s) {

    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission (this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale (this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
                new AlertDialog.Builder (this)
                        .setTitle ("Take permmsion")
                        .setMessage ("No permmision")
                        .setPositiveButton ("Ok", new DialogInterface.OnClickListener () {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Prompt the user once explanation has been shown
                                ActivityCompat.requestPermissions (MainActivity.this,
                                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                                        MY_PERMISSIONS_REQUEST_LOCATION);
                            }
                        })
                        .create ()
                        .show ();


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions (this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission (this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {
                    }

                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

        }
    }
}
