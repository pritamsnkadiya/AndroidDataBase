package com.example.pritam.testapp.database.modelClass;

/**
 * Created by manjoor on 18-Sep-18.
 */

public class SearchDetailsModel {
    String id;
    String c_name;
    String c_Mwith;
    String c_email;
    String c_mobile;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getC_name() {
        return c_name;
    }

    public void setC_name(String c_name) {
        this.c_name = c_name;
    }

    public String getC_Mwith() {
        return c_Mwith;
    }

    public void setC_Mwith(String c_Mwith) {
        this.c_Mwith = c_Mwith;
    }

    public String getC_email() {
        return c_email;
    }

    public void setC_email(String c_email) {
        this.c_email = c_email;
    }

    public String getC_mobile() {
        return c_mobile;
    }

    public void setC_mobile(String c_mobile) {
        this.c_mobile = c_mobile;
    }
}
