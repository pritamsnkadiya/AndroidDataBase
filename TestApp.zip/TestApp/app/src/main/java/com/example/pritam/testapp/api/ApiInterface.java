package com.example.pritam.testapp.api;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface ApiInterface {

    public static final int DEFAULT_PAGE_SIZE = 10;

  /*  @Headers({"Accept: application/json"})
    @GET
    Call<GetStateResponse> getStateResult(@Url String url, @Header("Authorization") String tokenId);*/
/*
    @Headers({"content-type: application/json"})
    @POST("/api/profile/insertRating")
    Call<RatingTestResponse> ratingTestRequestApi(@Body RatingTestRequest request);*/
}