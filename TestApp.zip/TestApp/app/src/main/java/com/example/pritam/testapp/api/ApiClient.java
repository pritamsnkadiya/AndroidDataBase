package com.example.pritam.testapp.api;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;


import java.io.Serializable;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient implements Serializable {

    private static final String TAG = ApiClient.class.getSimpleName ();

    private static final boolean production = false;
    private static final String BASE_URL = "https://www.pzitestportal.co.in/api/profile/index/";
    private static final Object mLock = new Object ();
    private static Retrofit retrofit = null;
    private static ApiClient apiClient;
    private Context context;
    int Uid;

    public ApiClient() {

    }

    public ApiClient(Context context) {
        this.context = context;
    }

    public static boolean isProduction() {
        return production;
    }

    public static ApiClient getSingletonApiClient() {
        synchronized (mLock) {
            if (apiClient == null)
                apiClient = new ApiClient ();
            return apiClient;
        }
    }

    private static Retrofit getClient() {
        if (retrofit == null) {
            //OkHttpClient.Builder client = new OkHttpClient.Builder();

            OkHttpClient.Builder okHttpClient = new OkHttpClient ().newBuilder ()
                    .connectTimeout (60 * 5, TimeUnit.SECONDS)
                    .readTimeout (60 * 5, TimeUnit.SECONDS)
                    .writeTimeout (60 * 5, TimeUnit.SECONDS);

            GsonConverterFactory gsonConverterFactory = GsonConverterFactory.create ();
            retrofit = new Retrofit.Builder ()
                    .baseUrl (BASE_URL)
                    .client (okHttpClient.build ())
                    .addConverterFactory (gsonConverterFactory)
                    .build ();
        }
        return retrofit;
    }
/*
    public void stateGetResponseCall(String token, Callback<GetStateResponse> callback) {
        Call<GetStateResponse> call = null;
        try {
            ApiInterface apiService = ApiClient.getClient ().create (ApiInterface.class);
            Log.d (TAG, "StateResponse Request URL : " + Constant.STATE_API_GET_RESPONSE);
            //Log.d(TAG, "OrderDetail Request URL : "+BASE_URL + Constant.API_ORDERS+id);
            call = apiService.getStateResult (Constant.STATE_API_GET_RESPONSE, token);
            call.enqueue (callback);
        } catch (Exception e) {
            Log.e (TAG, e.toString (), e);
            callback.onFailure (call, e);
        }
    }*/

/*    public void CityGetResponseCall(String token, Callback<GetCityResponse> callback) {
        Call<GetCityResponse> call = null;
        try {
            ApiInterface apiService = ApiClient.getClient ().create (ApiInterface.class);
            Log.d (TAG, "CityResponse Request URL : " + Constant.CITY_API_GET_RESPONSE);
            //Log.d(TAG, "OrderDetail Request URL : "+BASE_URL + Constant.API_ORDERS+id);
            call = apiService.getCityResult (Constant.CITY_API_GET_RESPONSE, token);
            call.enqueue (callback);
        } catch (Exception e) {
            Log.e (TAG, e.toString (), e);
            callback.onFailure (call, e);
        }
    }*/

 /*
    public void testResultDetailsCall(TestResultRequest request, Callback<TestResultResponse> callback) {
        Call<TestResultResponse> call = null;
        try {
            ApiInterface apiService = ApiClient.getClient ().create (ApiInterface.class);
            Log.d (TAG, "TestResult Request URL : " + BASE_URL);
            call = apiService.getTestResultRequest (request);
            call.enqueue (callback);
        } catch (Exception e) {
            Log.e (TAG, e.toString (), e);
            callback.onFailure (call, e);
        }
    }*/

}