package com.example.pritam.testapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.pritam.testapp.database.modelClass.ClientDetailsModel;
import com.example.pritam.testapp.database.modelClass.SearchDetailsModel;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    //Datebase name
    public static String DATABASE_NAME = "database";
    int DATABASE_VERSION = 1;
    //Table Name
    public static final String TABLE_NAME = "clint_data";
    //Column Name
    private static final String AUTO_INCREMENT_ID = "id";
    public static final String C_NAME = "c_name";
    public static final String C_EMAIL = "c_email";
    public static final String C_MOBILE = "c_mobile";
    public static final String MEETING = "c_Mwith";
    public static final String PURPOSE = "c_purpose";
    public static final String COMMENTS = "c_comments";
    public static final String LOCATIONS = "location";
    public static final String DATE = "date";


    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, 1);
        // DBHandler db = new DBHandler(context);
        createTable(this.getWritableDatabase());
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void createTable(SQLiteDatabase db) {
        if (db == null) {
            db = this.getWritableDatabase();
        }
        String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "("
                + AUTO_INCREMENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + C_NAME + " TEXT,"
                + C_EMAIL + " TEXT,"
                + C_MOBILE + " TEXT,"
                + MEETING + " TEXT,"
                + PURPOSE + " TEXT,"
                + COMMENTS + " TEXT,"
                + LOCATIONS + " TEXT,"
                + DATE + " TEXT" + ")";
        db.execSQL(CREATE_TABLE);
    }

    public void deleteTable() {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        createTable(db);
    }


    public long insertData(ClientDetailsModel model) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues ();
        values.put(C_NAME, model.getC_name());
        values.put(C_EMAIL, model.getC_email ());
        values.put(C_MOBILE, model.getC_mobile ());
        values.put(MEETING, model.getC_Mwith ());
        values.put(PURPOSE, model.getC_purpose ());
        values.put(COMMENTS, model.getC_comments ());
        values.put(LOCATIONS, model.getC_location ());
        values.put(DATE, model.getDate ());
        long result = db.insert(TABLE_NAME, null, values);
        return result;
    }


    public long updateData(ClientDetailsModel model, String id) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues ();
        values.put(C_NAME, model.getC_name());
        values.put(C_EMAIL, model.getC_email());
        values.put(C_MOBILE, model.getC_mobile ());
        values.put(MEETING, model.getC_Mwith ());
        values.put(PURPOSE, model.getC_purpose ());
        values.put(COMMENTS, model.getC_comments ());
        values.put(LOCATIONS, model.getC_location ());
        values.put(DATE, model.getDate());
        long result = db.update(TABLE_NAME, values, AUTO_INCREMENT_ID + " = '" + id + "' ", null);
        return result;
    }

    public long deleteData(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, AUTO_INCREMENT_ID + " = '" + id + "'", null);
        db.close();
        return result;
    }


    public ArrayList<ClientDetailsModel> getAllDataList() {
        // Select All Query
        ArrayList<ClientDetailsModel> dataList = new ArrayList<ClientDetailsModel> ();
        String selectQuery2 =
                "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery2, null);
        if (cursor.moveToFirst()) {
            do {

                ClientDetailsModel model = new ClientDetailsModel();
                model.setId(cursor.getString(cursor.getColumnIndex(AUTO_INCREMENT_ID)));
                model.setC_name(cursor.getString(cursor.getColumnIndex(C_NAME)));
                model.setC_email(cursor.getString(cursor.getColumnIndex(C_EMAIL)));
                model.setC_mobile (cursor.getString(cursor.getColumnIndex(C_MOBILE)));
                model.setC_Mwith (cursor.getString(cursor.getColumnIndex(MEETING)));
                model.setC_purpose (cursor.getString(cursor.getColumnIndex(PURPOSE)));
                model.setC_comments (cursor.getString(cursor.getColumnIndex(COMMENTS)));
                model.setC_location (cursor.getString(cursor.getColumnIndex(LOCATIONS)));
                model.setDate(cursor.getString(cursor.getColumnIndex(DATE)));
                dataList.add(model);
            } while (cursor.moveToNext());
        }
        return dataList;
    }


    public ArrayList<SearchDetailsModel> getSearchDataList() {
        // Select All Query
        ArrayList<SearchDetailsModel> dataList = new ArrayList<SearchDetailsModel> ();
        String selectQuery2 =
                "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery2, null);
        if (cursor.moveToFirst()) {
            do {

                SearchDetailsModel model = new SearchDetailsModel();
                model.setId(cursor.getString(cursor.getColumnIndex(AUTO_INCREMENT_ID)));
                model.setC_name(cursor.getString(cursor.getColumnIndex(C_NAME)));
                model.setC_email(cursor.getString(cursor.getColumnIndex(C_EMAIL)));
                model.setC_mobile (cursor.getString(cursor.getColumnIndex(C_MOBILE)));
                model.setC_Mwith (cursor.getString(cursor.getColumnIndex(MEETING)));
                dataList.add(model);
            } while (cursor.moveToNext());
        }
        return dataList;
    }
}
