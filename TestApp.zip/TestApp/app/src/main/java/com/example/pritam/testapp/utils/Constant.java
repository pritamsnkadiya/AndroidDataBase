package com.example.pritam.testapp.utils;

public class Constant{

    private static final String BASE_URL = "";
   }